package people;

public class Student extends Person {
	private double gpa; // An extra field specifically attached to Students, not all people
	
	public Student(String firstName, String lastName, int age, double gpa) {
		super(firstName, lastName, age);
		this.gpa = gpa;
	}
	
	// Getters
	public double getGpa() {
		return this.gpa;
	}
	
	//Setters
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	// Recitation C - Overrides Person.printOut() to also print the GPA
	@Override
	public void printOut() {
		System.out.println(getFirstName() + " " + getLastName() + ": " + getAge() + " " + getGpa());
	}
	
	//Recitation D - Overrides Person.getFullName() and instead prints the last name, followed by the first name
	@Override
	public String getFullName() {
		return getLastName() + " " + getFirstName();
	}
}
