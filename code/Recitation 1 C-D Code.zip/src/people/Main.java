package people;

public class Main {

	public static void main(String[] args) {
		System.out.println("Recitation C:");
		Person p1 = new Person("First", "Last", 20);  // Create a new person
		Person p2 = new Person("Huihai", "Zhou", 25); // Create another person
		p1.printOut(); // Print details for person 1
		p2.printOut(); // Print details for person 2
		p2.setAge(30); // Use setter to change age of person 2
		p2.printOut(); // Print new details of person 2
		Student student = new Student("Evan", "Garrahy", 20, 4.0); // Create new Student
		student.printOut(); // Print details of student
		
		
		System.out.println();
		System.out.println();
		
		
		System.out.println("Recitation D:");
		// Person
		Person person1 = new Person("Lem", "Hackett", 30);
		System.out.println("Full name: " + person1.getFullName());
		
		// Student - This will print the name backwards, as getFullName is overridden in Student
		Student student1 = new Student("Sam", "Smith", 19, 4.0);
		System.out.println("Full name: " + student1.getFullName());
	}

}
