package people;

public class Person {
	// Fields
	private String firstName;
	private String lastName;
	private int age;
	
	// Constructor
	public Person(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	
	// Getters
	public String getFirstName() { 
		return this.firstName;
	}
	
	public String getLastName() { 
		return this.lastName;
	}
	
	public int getAge() { 
		return this.age;
	}
	
	// Setters
	public void setFirstName(String name) {
		this.firstName = name;
	}
	
	public void setLastName(String name) {
		this.lastName = name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	// Recitation C - Prints out the name of the person, followed by their age
	public void printOut() {
		System.out.println(getFirstName() + " " + getLastName() + ": " + getAge());
	}
	
	// Recitation D - Returns the first and last name
	public String getFullName() {
		return firstName + " " + lastName; // firstname lastname
	}
}
