package classes;

public interface Colorable {
	
		public String getColor();
}
