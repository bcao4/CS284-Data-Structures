package classes;

public class PairIntInt {
	// Data fields
	private int fst;
	private int snd;
	public PairIntInt(int fst, int snd) {
		super();
		this.fst = fst;
		this.snd = snd;
	}
	public int getFst() {
		return fst;
	}
	public void setFst(int fst) {
		this.fst = fst;
	}
	public int getSnd() {
		return snd;
	}
	public void setSnd(int snd) {
		this.snd = snd;
	}
	
	
}
