package classes;

public class MyList<E> {
	// Data fields
	private E[] data;
	
	// Constructor
	MyList(int length) {
		data = (E[]) new Object[length];
	}

	// Methods
	public E get(int i) {
		if (i>data.length) {
			throw new ArrayIndexOutOfBoundsException();
		} else {
			return data[i];
		}
	}

	public void set(int i, E element) {
		if (i>data.length) {
			throw new ArrayIndexOutOfBoundsException();
		} else {
			data[i]=element;
		}
	}

}
