package classes;

public class Square extends Rectangle {
	// Constructor
	Square(int width, String color) {
		super(width,width,color);
	}
	
	
}
